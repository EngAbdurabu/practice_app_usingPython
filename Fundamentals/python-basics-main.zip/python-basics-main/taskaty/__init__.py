import taskaty.app

def main():
    taskaty.app.main()
